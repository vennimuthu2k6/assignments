import java.util.Scanner;

public class Transverse {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int rows = sc.nextInt();
        int colm = sc.nextInt();
        for (int i = 1;i<=colm;i++){
            for (int j = 1;j<=rows;j++){
                System.out.print(i*j + " ");
            }
            System.out.println();
        }
    }
}
