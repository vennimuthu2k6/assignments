# assignments
placement Training
